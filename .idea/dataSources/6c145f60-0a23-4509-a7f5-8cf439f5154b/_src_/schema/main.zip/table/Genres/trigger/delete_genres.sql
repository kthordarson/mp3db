CREATE TRIGGER delete_genres DELETE ON Genres
BEGIN
  DELETE FROM GenresSongs WHERE GenresSongs.IDGenre=old.IDGenre;
  DELETE FROM SynchGenre WHERE SynchGenre.IDGenre=old.IDGenre;
END