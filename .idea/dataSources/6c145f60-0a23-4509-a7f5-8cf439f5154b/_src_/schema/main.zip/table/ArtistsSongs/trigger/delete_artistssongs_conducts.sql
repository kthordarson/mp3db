CREATE TRIGGER delete_artistssongs_conducts DELETE ON ArtistsSongs WHEN old.PersonType=4
BEGIN
  UPDATE Artists SET Conducts=Conducts-1 WHERE Artists.ID=old.IDArtist;
END