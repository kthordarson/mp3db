CREATE TRIGGER insert_artistssongs_authors INSERT ON ArtistsSongs WHEN new.PersonType=3
BEGIN
  UPDATE Artists SET Authors=ifnull(Authors,0)+1 WHERE Artists.ID=new.IDArtist;
END