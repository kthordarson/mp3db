CREATE TRIGGER delete_artistssongs_publishes DELETE ON ArtistsSongs WHEN old.PersonType=8
BEGIN
  UPDATE Artists SET Publishes=Publishes-1 WHERE Artists.ID=old.IDArtist;
END