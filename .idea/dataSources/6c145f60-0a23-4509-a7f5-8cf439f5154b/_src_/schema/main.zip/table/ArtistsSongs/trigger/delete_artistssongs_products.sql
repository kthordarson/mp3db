CREATE TRIGGER delete_artistssongs_products DELETE ON ArtistsSongs WHEN old.PersonType=6
BEGIN
  UPDATE Artists SET Products=Products-1 WHERE Artists.ID=old.IDArtist;
END