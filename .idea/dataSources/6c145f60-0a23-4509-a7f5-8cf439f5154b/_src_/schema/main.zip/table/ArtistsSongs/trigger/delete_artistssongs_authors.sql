CREATE TRIGGER delete_artistssongs_authors DELETE ON ArtistsSongs WHEN old.PersonType=3
BEGIN
  UPDATE Artists SET Authors=Authors-1 WHERE Artists.ID=old.IDArtist;
END