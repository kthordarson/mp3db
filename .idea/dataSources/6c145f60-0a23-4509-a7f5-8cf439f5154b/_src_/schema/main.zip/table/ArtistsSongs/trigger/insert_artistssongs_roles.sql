CREATE TRIGGER insert_artistssongs_roles INSERT ON ArtistsSongs WHEN new.PersonType=7
BEGIN
  UPDATE Artists SET Roles=ifnull(Roles,0)+1 WHERE Artists.ID=new.IDArtist;
END