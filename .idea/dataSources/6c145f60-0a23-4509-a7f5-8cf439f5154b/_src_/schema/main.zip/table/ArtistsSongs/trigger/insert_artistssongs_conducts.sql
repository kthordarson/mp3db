CREATE TRIGGER insert_artistssongs_conducts INSERT ON ArtistsSongs WHEN new.PersonType=4
BEGIN
  UPDATE Artists SET Conducts=ifnull(Conducts,0)+1 WHERE Artists.ID=new.IDArtist;
END