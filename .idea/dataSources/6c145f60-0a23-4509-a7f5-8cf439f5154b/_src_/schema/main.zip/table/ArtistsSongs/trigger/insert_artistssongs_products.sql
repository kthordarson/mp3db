CREATE TRIGGER insert_artistssongs_products INSERT ON ArtistsSongs WHEN new.PersonType=6
BEGIN
  UPDATE Artists SET Products=ifnull(Products,0)+1 WHERE Artists.ID=new.IDArtist;
END