CREATE TRIGGER delete_artistssongs_roles DELETE ON ArtistsSongs WHEN old.PersonType=7
BEGIN
  UPDATE Artists SET Roles=Roles-1 WHERE Artists.ID=old.IDArtist;
END