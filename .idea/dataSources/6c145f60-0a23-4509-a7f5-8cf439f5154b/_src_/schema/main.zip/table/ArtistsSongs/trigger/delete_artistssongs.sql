CREATE TRIGGER delete_artistssongs DELETE ON ArtistsSongs WHEN old.PersonType=1
BEGIN
  UPDATE Artists SET Tracks=Tracks-1 WHERE Artists.ID=old.IDArtist;
END