CREATE TRIGGER insert_artistssongs_lyrics INSERT ON ArtistsSongs WHEN new.PersonType=5
BEGIN
  UPDATE Artists SET Lyrics=ifnull(Lyrics,0)+1 WHERE Artists.ID=new.IDArtist;
END