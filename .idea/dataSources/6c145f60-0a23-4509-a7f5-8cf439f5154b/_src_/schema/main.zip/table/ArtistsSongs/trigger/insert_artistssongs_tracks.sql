CREATE TRIGGER insert_artistssongs_tracks INSERT ON ArtistsSongs WHEN new.PersonType=1
BEGIN
  UPDATE Artists SET Tracks=ifnull(Tracks,0)+1 WHERE Artists.ID=new.IDArtist;
END