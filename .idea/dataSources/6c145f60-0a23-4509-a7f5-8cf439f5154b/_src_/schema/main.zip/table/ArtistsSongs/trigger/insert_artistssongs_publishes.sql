CREATE TRIGGER insert_artistssongs_publishes INSERT ON ArtistsSongs WHEN new.PersonType=8
BEGIN
  UPDATE Artists SET Publishes=ifnull(Publishes,0)+1 WHERE Artists.ID=new.IDArtist;
END