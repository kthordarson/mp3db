CREATE TRIGGER delete_artistssongs_lyrics DELETE ON ArtistsSongs WHEN old.PersonType=5
BEGIN
  UPDATE Artists SET Lyrics=Lyrics-1 WHERE Artists.ID=old.IDArtist;
END