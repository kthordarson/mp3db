CREATE TRIGGER delete_podcasts DELETE ON Podcasts
BEGIN
  DELETE FROM PodcastEpisodes WHERE PodcastEpisodes.IDPodcast=old.ID;
  DELETE FROM SynchPodcast WHERE SynchPodcast.IDPodcast=old.ID;
END