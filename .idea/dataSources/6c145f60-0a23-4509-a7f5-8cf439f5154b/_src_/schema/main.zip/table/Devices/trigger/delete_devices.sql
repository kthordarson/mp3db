CREATE TRIGGER delete_devices DELETE ON Devices
BEGIN
  DELETE FROM NodeViews WHERE NodeViews.DeviceID=old.DeviceID;
  DELETE FROM DeviceTracks WHERE DeviceTracks.IDDevice=old.ID;
  DELETE FROM SynchLocation WHERE SynchLocation.IDDevice=old.ID;
  DELETE FROM SynchArtist WHERE SynchArtist.IDDevice=old.ID;
  DELETE FROM SynchAlbum WHERE SynchAlbum.IDDevice=old.ID;
  DELETE FROM SynchGenre WHERE SynchGenre.IDDevice=old.ID;
  DELETE FROM SynchRating WHERE SynchRating.IDDevice=old.ID;
  DELETE FROM SynchPlaylist WHERE SynchPlaylist.IDDevice=old.ID;
  DELETE FROM SynchPodcast WHERE SynchPodcast.IDDevice=old.ID;
  DELETE FROM SynchCollection WHERE SynchCollection.IDDevice=old.ID;
END