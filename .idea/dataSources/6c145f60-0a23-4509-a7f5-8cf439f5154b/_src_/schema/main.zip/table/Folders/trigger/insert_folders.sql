CREATE TRIGGER insert_folders AFTER INSERT ON Folders
BEGIN
  INSERT INTO FoldersHier (IDFolder,IDChildFolder) SELECT IDFolder,new.ID FROM FoldersHier WHERE IDChildFolder=new.IDParentFolder;
  INSERT INTO FoldersHier (IDFolder,IDChildFolder) VALUES (new.ID,new.ID);
END