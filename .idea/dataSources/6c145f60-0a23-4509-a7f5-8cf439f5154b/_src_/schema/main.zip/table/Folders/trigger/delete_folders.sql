CREATE TRIGGER delete_folders DELETE ON Folders
BEGIN
  DELETE FROM FoldersHier WHERE IDChildFolder=old.ID;
END