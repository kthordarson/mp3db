CREATE TRIGGER delete_medias DELETE ON Medias
BEGIN
  DELETE FROM Songs WHERE Songs.IDMedia=old.IDMedia;
  DELETE FROM Folders WHERE Folders.IDMedia = old.IDMedia;
  DELETE FROM PathProcessing WHERE PathProcessing.IDMedia = old.IDMedia;
  DELETE FROM SynchLocation WHERE SynchLocation.IDMedia = old.IDMedia;
END