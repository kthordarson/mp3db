CREATE TRIGGER update_artistsalbums UPDATE ON ArtistsAlbums
BEGIN
  UPDATE Artists SET Albums=ifnull(Albums,0)+1 WHERE Artists.ID=new.IDArtist;
  UPDATE Artists SET Albums=Albums-1 WHERE Artists.ID=old.IDArtist;
END