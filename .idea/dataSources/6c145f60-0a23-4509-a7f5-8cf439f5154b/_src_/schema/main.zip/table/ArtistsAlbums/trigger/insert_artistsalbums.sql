CREATE TRIGGER insert_artistsalbums INSERT ON ArtistsAlbums
BEGIN
  UPDATE Artists SET Albums=ifnull(Albums,0)+1 WHERE Artists.ID=new.IDArtist;
END