CREATE TRIGGER delete_artistsalbums DELETE ON ArtistsAlbums
BEGIN
  UPDATE Artists SET Albums=Albums-1 WHERE Artists.ID=old.IDArtist;
END