CREATE TRIGGER update_idepisode UPDATE OF IDTrack ON PodcastEpisodes WHEN new.IDTrack<>old.IDTrack 
BEGIN
  UPDATE Songs SET IDEpisode = -1 WHERE ID = old.IDTrack;
  UPDATE Songs SET IDEpisode = new.ID WHERE ID = new.IDTrack;
END