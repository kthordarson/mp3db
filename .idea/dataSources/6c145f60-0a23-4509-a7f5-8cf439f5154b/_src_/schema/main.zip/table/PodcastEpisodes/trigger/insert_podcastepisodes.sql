CREATE TRIGGER insert_podcastepisodes AFTER INSERT ON PodcastEpisodes WHEN new.IDTrack > -1 
BEGIN
  UPDATE Songs SET IDEpisode = new.ID WHERE Songs.ID = new.IDTrack;
END