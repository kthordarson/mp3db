CREATE TRIGGER delete_podcastepisodes DELETE ON PodcastEpisodes
BEGIN
  UPDATE Songs SET IDEpisode = -1 WHERE Songs.ID = old.IDTrack;
END