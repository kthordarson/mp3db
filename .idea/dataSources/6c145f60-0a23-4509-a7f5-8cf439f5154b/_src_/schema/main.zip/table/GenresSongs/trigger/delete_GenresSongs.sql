CREATE TRIGGER delete_GenresSongs DELETE ON GenresSongs
BEGIN
  UPDATE Genres SET UsageCount=UsageCount-1 WHERE Genres.IDGenre=old.IDGenre;
  DELETE FROM  Genres WHERE Genres.IDGenre=old.IDGenre AND Genres.UsageCount=0;
END