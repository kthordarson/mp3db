CREATE TRIGGER insert_GenresSongs INSERT ON GenresSongs
BEGIN
  UPDATE Genres SET UsageCount=ifnull(UsageCount,0)+1 WHERE Genres.IDGenre=new.IDGenre;
END