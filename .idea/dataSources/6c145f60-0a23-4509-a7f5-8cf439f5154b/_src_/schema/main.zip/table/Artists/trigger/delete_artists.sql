CREATE TRIGGER delete_artists DELETE ON Artists
BEGIN
  DELETE FROM ArtistsAlbums WHERE ArtistsAlbums.IDArtist=old.ID;
  DELETE FROM ArtistsSongs WHERE ArtistsSongs.IDArtist=old.ID;
  DELETE FROM SynchArtist WHERE SynchArtist.IDArtist=old.ID;
END