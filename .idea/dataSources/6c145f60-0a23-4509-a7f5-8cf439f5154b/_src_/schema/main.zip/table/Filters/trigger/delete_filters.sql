CREATE TRIGGER delete_filters DELETE ON Filters
BEGIN
  UPDATE Playlists SET IDFilter=-1 WHERE IDFilter=old.ID;
END