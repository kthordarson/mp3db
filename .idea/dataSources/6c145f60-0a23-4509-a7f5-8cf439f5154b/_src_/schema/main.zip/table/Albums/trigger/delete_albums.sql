CREATE TRIGGER delete_albums DELETE ON Albums
BEGIN
  DELETE FROM ArtistsAlbums WHERE ArtistsAlbums.IDAlbum=old.ID;
  DELETE FROM SynchAlbum WHERE SynchAlbum.IDAlbum=old.ID;
END