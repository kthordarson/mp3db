CREATE TRIGGER update_songs_tempo UPDATE OF tempo ON Songs WHEN new.tempo<>old.tempo
BEGIN
  UPDATE SongsText SET tempo=new.tempo WHERE rowid=new.id;
END