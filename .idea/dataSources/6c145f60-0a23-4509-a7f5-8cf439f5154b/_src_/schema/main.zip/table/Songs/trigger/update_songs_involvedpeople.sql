CREATE TRIGGER update_songs_involvedpeople UPDATE OF involvedpeople ON Songs WHEN new.involvedpeople<>old.involvedpeople
BEGIN
  UPDATE SongsText SET involvedpeople=new.involvedpeople WHERE rowid=new.id;
END