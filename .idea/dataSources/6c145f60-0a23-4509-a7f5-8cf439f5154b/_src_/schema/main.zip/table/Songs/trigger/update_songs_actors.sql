CREATE TRIGGER update_songs_actors UPDATE OF actors ON Songs WHEN new.actors<>old.actors
BEGIN
  UPDATE SongsText SET actors=new.actors WHERE rowid=new.id;
END