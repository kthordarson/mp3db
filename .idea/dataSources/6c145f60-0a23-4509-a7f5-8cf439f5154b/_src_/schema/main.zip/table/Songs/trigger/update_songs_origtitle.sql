CREATE TRIGGER update_songs_origtitle UPDATE OF origtitle ON Songs WHEN new.origtitle<>old.origtitle
BEGIN
  UPDATE SongsText SET origtitle=new.origtitle WHERE rowid=new.id;
END