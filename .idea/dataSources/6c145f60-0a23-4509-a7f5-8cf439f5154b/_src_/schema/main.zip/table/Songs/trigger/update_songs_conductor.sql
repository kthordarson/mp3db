CREATE TRIGGER update_songs_conductor UPDATE OF conductor ON Songs WHEN new.conductor<>old.conductor
BEGIN
  UPDATE SongsText SET conductor=new.conductor WHERE rowid=new.id;
END