CREATE TRIGGER update_songs_copyright UPDATE OF copyright ON Songs WHEN new.copyright<>old.copyright
BEGIN
  UPDATE SongsText SET copyright=new.copyright WHERE rowid=new.id;
END