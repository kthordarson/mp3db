CREATE TRIGGER update_songs_custom4 UPDATE OF custom4 ON Songs WHEN new.custom4<>old.custom4
BEGIN
  UPDATE SongsText SET custom4=new.custom4 WHERE rowid=new.id;
END