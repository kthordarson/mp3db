CREATE TRIGGER update_songs_author UPDATE OF author ON Songs WHEN new.author<>old.author
BEGIN
  UPDATE SongsText SET author=new.author WHERE rowid=new.id;
END