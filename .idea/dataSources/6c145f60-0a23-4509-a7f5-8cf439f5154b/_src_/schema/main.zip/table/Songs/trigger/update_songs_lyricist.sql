CREATE TRIGGER update_songs_lyricist UPDATE OF lyricist ON Songs WHEN new.lyricist<>old.lyricist
BEGIN
  UPDATE SongsText SET lyricist=new.lyricist WHERE rowid=new.id;
END