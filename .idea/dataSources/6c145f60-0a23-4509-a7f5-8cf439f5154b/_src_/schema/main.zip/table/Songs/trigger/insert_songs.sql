CREATE TRIGGER insert_songs AFTER INSERT ON Songs
BEGIN
  UPDATE Albums SET Tracks=ifnull(Tracks,0)+1 WHERE Albums.ID=new.IDAlbum;
  INSERT INTO PathProcessing (IDMedia,Path,Action,IDSong) VALUES (new.IDMedia,new.SongPath,1,new.ID);
  INSERT INTO SongsText (rowid,artist,album,albumartist,songtitle,genre,songpath,author,lyricist,conductor,groupdesc,subtitle,lyrics,comment,custom1,custom2,custom3,custom4,custom5,origartist,origtitle,origlyricist,publisher,encoder,copyright,mood,tempo,occasion,quality,involvedpeople,producer,actors) VALUES (new.id,new.Artist,new.Album,new.AlbumArtist,new.SongTitle,new.Genre,new.SongPath,new.Author,new.Lyricist,new.Conductor,new.GroupDesc,new.SubTitle,new.Lyrics,new.Comment,new.custom1,new.custom2,new.custom3,new.custom4,new.custom5,new.origartist,new.origtitle,new.origlyricist,new.publisher,new.encoder,new.copyright,new.mood,new.tempo,new.occasion,new.quality,new.involvedpeople,new.producer,new.actors);
  UPDATE Songs SET Extension = getextension( new.SongPath) WHERE ID = new.ID;
  UPDATE Songs SET IDEpisode = -1 WHERE ID = new.ID;
END