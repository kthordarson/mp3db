CREATE TRIGGER update_songs_songpath UPDATE OF IDMedia, SongPath ON Songs WHEN new.SongPath<>old.SongPath OR new.IDMedia<>old.IDMedia
BEGIN
  INSERT INTO PathProcessing (IDMedia,Path,Action,IDSong) VALUES (old.IDMedia,old.SongPath,2,new.ID);
  INSERT INTO PathProcessing (IDMedia,Path,Action,IDSong) VALUES (new.IDMedia,new.SongPath,1,new.ID);
  UPDATE SongsText SET songpath=new.SongPath WHERE rowid=new.id;
  UPDATE Songs SET Extension = getextension( new.SongPath) WHERE ID = new.ID;
END