CREATE TRIGGER update_songs_custom1 UPDATE OF custom1 ON Songs WHEN new.custom1<>old.custom1
BEGIN
  UPDATE SongsText SET custom1=new.custom1 WHERE rowid=new.id;
END