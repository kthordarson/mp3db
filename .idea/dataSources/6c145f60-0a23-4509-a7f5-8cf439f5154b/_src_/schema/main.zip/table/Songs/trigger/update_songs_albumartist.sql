CREATE TRIGGER update_songs_albumartist UPDATE OF albumartist ON Songs WHEN new.albumartist<>old.albumartist
BEGIN
  UPDATE SongsText SET albumartist=new.albumartist WHERE rowid=new.id;
END