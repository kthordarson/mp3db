CREATE TRIGGER update_songs_comment UPDATE OF comment ON Songs WHEN new.comment<>old.comment
BEGIN
  UPDATE SongsText SET comment=new.comment WHERE rowid=new.id;
END