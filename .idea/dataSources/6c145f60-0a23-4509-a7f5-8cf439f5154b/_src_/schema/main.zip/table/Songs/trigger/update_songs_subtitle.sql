CREATE TRIGGER update_songs_subtitle UPDATE OF subtitle ON Songs WHEN new.subtitle<>old.subtitle
BEGIN
  UPDATE SongsText SET subtitle=new.subtitle WHERE rowid=new.id;
END