CREATE TRIGGER update_songs_occasion UPDATE OF occasion ON Songs WHEN new.occasion<>old.occasion
BEGIN
  UPDATE SongsText SET occasion=new.occasion WHERE rowid=new.id;
END