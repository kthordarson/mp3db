CREATE TRIGGER update_songs_tracktype UPDATE ON Songs WHEN new.TrackType<>old.TrackType 
BEGIN
  UPDATE ArtistsSongs SET TrackType=new.TrackType WHERE ArtistsSongs.IDSong = new.ID;
  UPDATE GenresSongs  SET TrackType=new.TrackType WHERE GenresSongs.IDSong  = new.ID;
END