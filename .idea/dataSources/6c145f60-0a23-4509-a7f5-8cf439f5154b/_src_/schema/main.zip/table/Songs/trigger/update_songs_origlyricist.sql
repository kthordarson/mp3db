CREATE TRIGGER update_songs_origlyricist UPDATE OF origlyricist ON Songs WHEN new.origlyricist<>old.origlyricist
BEGIN
  UPDATE SongsText SET origlyricist=new.origlyricist WHERE rowid=new.id;
END