CREATE TRIGGER delete_songs DELETE ON Songs
BEGIN
  DELETE FROM ArtistsSongs WHERE ArtistsSongs.IDSong=old.ID;
  DELETE FROM PlaylistSongs WHERE PlaylistSongs.IDSong=old.ID;
  DELETE FROM Covers WHERE Covers.IDSong=old.ID;
  DELETE FROM Played WHERE Played.IDSong=old.ID;
  DELETE FROM DeviceTracks WHERE DeviceTracks.IDTrack=old.ID;
  DELETE FROM GenresSongs WHERE GenresSongs.IDSong=old.ID;
  DELETE FROM ListsSongs WHERE ListsSongs.IDSong=old.ID;
  DELETE FROM PathProcessing WHERE PathProcessing.IDSong=old.ID;
  UPDATE Folders SET TrackCount=TrackCount-1 WHERE Folders.ID IN (SELECT IDFolder FROM FoldersHier WHERE FoldersHier.IDChildFolder=old.IDFolder);
  DELETE FROM Folders WHERE Folders.ID IN (SELECT IDFolder FROM FoldersHier WHERE FoldersHier.IDChildFolder=old.IDFolder) AND Folders.TrackCount<=0;
  UPDATE Albums SET Tracks=Tracks-1 WHERE Albums.ID=old.IDAlbum;
  DELETE FROM SongsText WHERE rowid=old.ID;
  UPDATE PodcastEpisodes SET idTrack = -1, ViewStatus = 1 WHERE PodcastEpisodes.idTrack=old.ID;
END