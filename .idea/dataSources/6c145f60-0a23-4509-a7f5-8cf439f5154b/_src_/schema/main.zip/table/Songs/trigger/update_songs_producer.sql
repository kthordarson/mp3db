CREATE TRIGGER update_songs_producer UPDATE OF producer ON Songs WHEN new.producer<>old.producer
BEGIN
  UPDATE SongsText SET producer=new.producer WHERE rowid=new.id;
END