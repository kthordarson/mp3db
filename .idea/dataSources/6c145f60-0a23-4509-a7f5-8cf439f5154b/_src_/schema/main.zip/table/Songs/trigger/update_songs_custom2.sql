CREATE TRIGGER update_songs_custom2 UPDATE OF custom2 ON Songs WHEN new.custom2<>old.custom2
BEGIN
  UPDATE SongsText SET custom2=new.custom2 WHERE rowid=new.id;
END