CREATE TRIGGER update_songs_artist UPDATE OF artist ON Songs WHEN new.artist<>old.artist
BEGIN
  UPDATE SongsText SET artist=new.artist WHERE rowid=new.id;
END