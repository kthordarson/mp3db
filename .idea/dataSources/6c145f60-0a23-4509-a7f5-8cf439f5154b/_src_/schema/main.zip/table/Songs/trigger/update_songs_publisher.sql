CREATE TRIGGER update_songs_publisher UPDATE OF publisher ON Songs WHEN new.publisher<>old.publisher
BEGIN
  UPDATE SongsText SET publisher=new.publisher WHERE rowid=new.id;
END