CREATE TRIGGER update_songs_quality UPDATE OF quality ON Songs WHEN new.quality<>old.quality
BEGIN
  UPDATE SongsText SET quality=new.quality WHERE rowid=new.id;
END