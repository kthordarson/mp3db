CREATE TRIGGER update_songs UPDATE ON Songs
BEGIN
  UPDATE Albums SET Tracks=Tracks-1 WHERE Albums.ID=old.IDAlbum;
  UPDATE Albums SET Tracks=ifnull(Tracks,0)+1 WHERE Albums.ID=new.IDAlbum;
END