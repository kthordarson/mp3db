CREATE TRIGGER update_songs_lyrics UPDATE OF lyrics ON Songs WHEN new.lyrics<>old.lyrics
BEGIN
  UPDATE SongsText SET lyrics=new.lyrics WHERE rowid=new.id;
END