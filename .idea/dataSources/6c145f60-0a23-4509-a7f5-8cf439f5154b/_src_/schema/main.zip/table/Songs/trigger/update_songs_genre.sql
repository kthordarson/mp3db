CREATE TRIGGER update_songs_genre UPDATE OF genre ON Songs WHEN new.genre<>old.genre
BEGIN
  UPDATE SongsText SET genre=new.genre WHERE rowid=new.id;
END