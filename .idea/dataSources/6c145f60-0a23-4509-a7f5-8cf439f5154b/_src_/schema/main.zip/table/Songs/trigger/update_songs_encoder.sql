CREATE TRIGGER update_songs_encoder UPDATE OF encoder ON Songs WHEN new.encoder<>old.encoder
BEGIN
  UPDATE SongsText SET encoder=new.encoder WHERE rowid=new.id;
END