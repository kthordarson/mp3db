CREATE TRIGGER update_songs_album UPDATE OF album ON Songs WHEN new.album<>old.album
BEGIN
  UPDATE SongsText SET album=new.album WHERE rowid=new.id;
END