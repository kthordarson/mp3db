CREATE TRIGGER update_songs_custom3 UPDATE OF custom3 ON Songs WHEN new.custom3<>old.custom3
BEGIN
  UPDATE SongsText SET custom3=new.custom3 WHERE rowid=new.id;
END