CREATE TRIGGER update_songs_songtitle UPDATE OF songtitle ON Songs WHEN new.songtitle<>old.songtitle
BEGIN
  UPDATE SongsText SET songtitle=new.songtitle WHERE rowid=new.id;
END