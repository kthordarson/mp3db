CREATE TRIGGER update_songs_mood UPDATE OF mood ON Songs WHEN new.mood<>old.mood
BEGIN
  UPDATE SongsText SET mood=new.mood WHERE rowid=new.id;
END