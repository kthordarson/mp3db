CREATE TRIGGER update_songs_custom5 UPDATE OF custom5 ON Songs WHEN new.custom5<>old.custom5
BEGIN
  UPDATE SongsText SET custom5=new.custom5 WHERE rowid=new.id;
END