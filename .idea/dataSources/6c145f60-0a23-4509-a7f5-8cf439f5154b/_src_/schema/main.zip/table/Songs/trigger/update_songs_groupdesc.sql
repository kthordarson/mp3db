CREATE TRIGGER update_songs_groupdesc UPDATE OF groupdesc ON Songs WHEN new.groupdesc<>old.groupdesc
BEGIN
  UPDATE SongsText SET groupdesc=new.groupdesc WHERE rowid=new.id;
END