CREATE TRIGGER update_songs_origartist UPDATE OF origartist ON Songs WHEN new.origartist<>old.origartist
BEGIN
  UPDATE SongsText SET origartist=new.origartist WHERE rowid=new.id;
END