CREATE TRIGGER update_playlistsongs AFTER UPDATE ON PlaylistSongs
BEGIN
  UPDATE Playlists SET LastModified=datetime('now') WHERE Playlists.IDPlaylist = new.IDPlaylist AND IsAutoPlaylist <> 1;
END