CREATE TRIGGER delete_playlistsongs AFTER DELETE ON PlaylistSongs
BEGIN
  UPDATE Playlists SET LastModified=datetime('now') WHERE Playlists.IDPlaylist = old.IDPlaylist AND IsAutoPlaylist <> 1;
END