CREATE TRIGGER insert_playlist AFTER INSERT ON Playlists
BEGIN
  UPDATE Playlists SET LastModified=datetime('now'), IsAutoPlaylist=ifnull(IsAutoPlaylist,0) WHERE Playlists.IDPlaylist = new.IDPlaylist;
END