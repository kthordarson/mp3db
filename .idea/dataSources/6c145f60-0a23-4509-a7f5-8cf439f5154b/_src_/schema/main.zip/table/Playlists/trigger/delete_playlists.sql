CREATE TRIGGER delete_playlists DELETE ON Playlists
BEGIN
  DELETE FROM PlaylistSongs WHERE PlaylistSongs.IDPlaylist=old.IDPlaylist;
  DELETE FROM SynchPlaylist WHERE SynchPlaylist.IDPlaylist=old.IDPlaylist;
END